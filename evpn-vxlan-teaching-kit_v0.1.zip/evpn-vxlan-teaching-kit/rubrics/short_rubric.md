# Short Grading Checklist (per lab)
- [ ] Configuration correctness (40%)
- [ ] Troubleshooting & verification (40%)
- [ ] Explanation/diagram clarity (20%)
